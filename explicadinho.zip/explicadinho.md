# OV7670 AXI VDMA 

Está aí um programa que funciona com três frame buffers pelo AXI VDMA. Não testei rigorosamente, minha intenção é somente mostrar onde vocês devem estudar para desenvolverem isto independentemente. 

O arquivo autogerado pela Xilinx é o "xaxivdma.h".  Nele, há uma série de funções que abstraem o hardware para linguagem C/C++ e com isso controlam AXI VDMA. Estas APIs geralmente são desenvolvidas para várias aplicações desde muito simples até algo realmente meticuloso, e às vezes, acaba por ser uma forma menos prática para resolver isto do que acessando o hardware diretamente.

O que eu aconselho é dedicar um tempo para ler o reference guide do AXI VDMA disponível em https://www.xilinx.com/support/documentation/ip_documentation/axi_vdma/v6_2/pg020_axi_vdma.pdf 

Neste documento é explicado como que o AXI VDMA é mapeado, os registradores com a disposição e funcionalidade de cada elemento. 

## Stream to Memory Map Register Detail - S2MM_VDMACR (S2MM VDMA Control Register – Offset 30h)

Este é o registrador que há algum alguma coisa mal configurada. Pagina 25 mostra todos os pontos da configuração desde registrador, em que o valor default para o número de framebuffer é 3 e as condições são analogas ao problema. Portanto, simplesmente colocando o valor de default nisso tudo.

$$ S2MM\_VDMACR= 0x8B $$

Ele habilita a captura dos 3 frame buffers

##### DEIXO PARA VOCES DESCOBRIREM QUAL É A PARTE DA API QUE ESTÁ CONFIGURANDO DE MANEIRA ERRADA O ESTE REGISTRADOR DE CONFIGURAÇÃO DO DMA
Dica: é so observar qual é a diferença entre o valores configurados para S2MM_VDMACR antigo e novo. 



## Aqui está o algoritmo da captura em python


```python
import serial
import io
import cv2
import numpy as np
buf0=np.zeros(shape=(480,640)).astype('uint8')
buf1=np.zeros(shape=(480,640)).astype('uint8')
buf2=np.zeros(shape=(480,640)).astype('uint8')
ser = serial.Serial()
ser.baudrate = 115200
ser.port = 'COM4'
ser.close()
ser.open()
sio = io.TextIOWrapper(io.BufferedRWPair(ser, ser))
for y in range(480):
    for x in range(640):
        arrd = ser.readline().decode("utf-8").split(' ')[0:3]
        buf0[y,x]=np.uint8(arrd[0])
        buf1[y,x]=np.uint8(arrd[1])
        buf2[y,x]=np.uint8(arrd[2])
    print(y)

grayimage=cv2.cvtColor(buf0,cv2.COLOR_GRAY2BGR)
cv2.imwrite('buff1.jpg',grayimage)

grayimage=cv2.cvtColor(buf1,cv2.COLOR_GRAY2BGR)
cv2.imwrite('buff2.jpg',grayimage)

grayimage=cv2.cvtColor(buf2,cv2.COLOR_GRAY2BGR)
cv2.imwrite('buff3.jpg',grayimage)
```

## Abanei o braço em frente a camera para mostrar que a captura é feita com diferentes imagens.


```python
import numpy as np 
import matplotlib.pyplot as plt 
from PIL import Image
```


```python
pic1 = Image.open('buff1.jpg')
pic1
```




    
![png](output_5_0.png)
    




```python
pic = Image.open('buff2.jpg')
pic
```




    
![png](output_6_0.png)
    




```python
pic = Image.open('buff3.jpg')
pic
```




    
![png](output_7_0.png)
    







```python

```


